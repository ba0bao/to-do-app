
import java.util.ArrayList;
import java.util.List;

public class ToDoList {
    private List<String> tasks = new ArrayList<>();

    public void addTask(String task) {
        tasks.add(task);
    }

    public void printTasks() {
        System.out.println("Your tasks:");
        for (int i = 0; i < tasks.size(); i++) {
            System.out.println((i + 1) + ". " + tasks.get(i));
        }
    }

    public void completeTask(int taskNumber) {
        tasks.remove(taskNumber - 1);
    }
}