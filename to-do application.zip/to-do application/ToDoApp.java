import java.util.Scanner;

public class ToDoApp {
    public static void main(String[] args) {
        ToDoList list = new ToDoList();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("Select an option (1 - 4):");
            System.out.println("1. Add a task:");
            System.out.println("2. View tasks:");
            System.out.println("3. Complete a task:");
            System.out.println("4. Quit");
            System.out.print("Enter a choice: ");
            int choice = scanner.nextInt();
            if (choice == 1) {
                System.out.print("Enter a task: ");
                scanner.nextLine();
                list.addTask(scanner.nextLine());
            } else if (choice == 2) {
                list.printTasks();
            } else if (choice == 3) {
                System.out.print("Enter a task number: ");
                list.completeTask(scanner.nextInt());
            }
        }
    }
}
